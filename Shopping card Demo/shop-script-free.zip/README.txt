
	+------------------+
	| Shop-Script FREE |
	+------------------+

Thank you for choosing Shop-Script FREE!

Before using this software please refer to installation
and usage instructions which can be downloaded from Shop-Script website:
http://www.shop-script.com


----
Copyright (c) 2005 WebAsyst LLC. All rights reserved.
Shop-Script homepage:
http://www.shop-script.com