<?php
	define('CONF_SHOP_NAME', 'My Online Store');
	define('CONF_SHOP_URL', 'www.mystore.com');
	define('CONF_GENERAL_EMAIL', 'your@email.here');
	define('CONF_ORDERS_EMAIL', 'your@email.here');
	define('CONF_CURRENCY_ID_LEFT', '$');
	define('CONF_CURRENCY_ID_RIGHT', '');
	define('CONF_CURRENCY_ISO3', 'USD');
	define('CONF_PAYPAL_EMAIL', 'your@paypal.email');
	define('CONF_PAYPAL_INTEGRATION', 1);
?>